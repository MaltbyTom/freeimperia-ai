# toolkits/snapshot_tools/snapshot_tools.py

import os
import re
import datetime
import glob
import yaml

def get_snapshot_list(snapshot_dir, legacy_ok=True):
    pattern_new = re.compile(r'fib_snapshot_(\d{8})_(\d{4})\.yaml$')
    pattern_old = re.compile(r'fib_snapshot_.*?(\d{8})([a-z])\.yaml$')
    snapshots = []

    for file in glob.glob(os.path.join(snapshot_dir, "*.yaml")):
        name = os.path.basename(file)
        match_new = pattern_new.match(name)
        if match_new:
            date = match_new.group(1)
            time = match_new.group(2)
            snapshots.append((f"{date}_{time}", name))
        elif legacy_ok:
            match_old = pattern_old.match(name)
            if match_old:
                date = match_old.group(1)
                suffix = match_old.group(2)
                snapshots.append((f"{date}_{suffix}", name))

    snapshots.sort(reverse=True)
    return snapshots

def load_snapshot(snapshot_path):
    with open(snapshot_path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)

def save_snapshot(data, output_dir):
    now = datetime.datetime.now()
    name = f"fib_snapshot_{now.strftime('%Y%m%d_%H%M')}.yaml"
    path = os.path.join(output_dir, name)
    with open(path, 'w', encoding='utf-8') as f:
        yaml.dump(data, f, allow_unicode=True)
    return name, path

def filter_snapshot(snapshot_data, keys_to_keep):
    return {key: val for key, val in snapshot_data.items() if key in keys_to_keep}