# toolkits/wiki_mining/jsonl_to_gml.py

import json

def jsonl_to_gml(jsonl_path, gml_path):
    """Convert a JSONL graph to GML format for visualization."""
    with open(jsonl_path, 'r', encoding='utf-8') as f:
        edges = [json.loads(line) for line in f]

    nodes = {}
    for edge in edges:
        nodes[edge['source']] = True
        nodes[edge['target']] = True

    with open(gml_path, 'w', encoding='utf-8') as f:
        f.write("graph [\n  directed 1\n")
        for node in nodes:
            f.write(f"  node [ id \"{node}\" label \"{node}\" ]\n")
        for edge in edges:
            f.write(f"  edge [ source \"{edge['source']}\" target \"{edge['target']}\" label \"{edge['link']}\" ]\n")
        f.write("]\n")