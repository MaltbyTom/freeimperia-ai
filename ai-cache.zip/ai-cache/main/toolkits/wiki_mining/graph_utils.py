# toolkits/wiki_mining/graph_utils.py

import json

def load_jsonl(file_path):
    """Load a JSONL file into a list of dicts."""
    with open(file_path, 'r', encoding='utf-8') as f:
        return [json.loads(line) for line in f]

def save_jsonl(data, file_path):
    """Save a list of dicts to a JSONL file."""
    with open(file_path, 'w', encoding='utf-8') as f:
        for item in data:
            f.write(json.dumps(item, ensure_ascii=False) + '\n')

def filter_by_relation(data, allowed_relations):
    """Filter a JSONL graph by allowed relation types."""
    return [item for item in data if item.get('link') in allowed_relations]

def remove_duplicate_edges(data):
    """Remove duplicate edges based on (source, target, link)."""
    seen = set()
    unique = []
    for edge in data:
        key = (edge.get('source'), edge.get('target'), edge.get('link'))
        if key not in seen:
            seen.add(key)
            unique.append(edge)
    return unique