import re

def extract_links_and_entities(text):
    """
    Parses DokuWiki syntax to extract internal links and inferred entities.

    Returns:
        dict: {
            'entities': list of extracted [[Entity]] names,
            'relationships': list of (source, target, label) if inferrable
        }
    """
    link_pattern = r'\[\[([^\]]+?)\]\]'
    matches = re.findall(link_pattern, text)
    entities = set()
    relationships = []

    for match in matches:
        if '|' in match:
            page_name, _ = match.split('|', 1)
        else:
            page_name = match
        entities.add(page_name.strip())

    return {
        'entities': list(entities),
        'relationships': relationships  # future extension
    }

def normalize_entity(entity_name):
    """
    Standardizes entity names to improve matching in graph generation.
    """
    return entity_name.strip().lower().replace(' ', '_')
