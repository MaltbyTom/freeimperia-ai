import os
import re
import json

def extract_relationships_from_wiki(wiki_dir, output_file):
    relationships = []
    link_pattern = re.compile(r'\[\[([^\[\]]+)\]\]')

    for root, _, files in os.walk(wiki_dir):
        for file in files:
            if file.endswith('.txt'):
                path = os.path.join(root, file)
                with open(path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    matches = link_pattern.findall(content)
                    source = os.path.splitext(file)[0]
                    for match in matches:
                        relationships.append({
                            'source': f'[[{source}]]',
                            'target': f'[[{match.strip()}]]',
                            'type': 'link'
                        })

    with open(output_file, 'w', encoding='utf-8') as out:
        for rel in relationships:
            out.write(json.dumps(rel) + '\n')
