# toolkit/wiki_mining/graph_data_model.py

from dataclasses import dataclass
from typing import List, Optional

@dataclass
class Entity:
    name: str
    wiki_link: Optional[str] = None
    type: Optional[str] = None
    description: Optional[str] = None

@dataclass
class Relationship:
    source: str
    target: str
    label: str
    sentence: Optional[str] = None

@dataclass
class WikiGraph:
    entities: List[Entity]
    relationships: List[Relationship]
