import json
import networkx as nx
import os

def load_jsonl(filename):
    with open(filename, "r", encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]

def jsonl_to_graph(data):
    G = nx.DiGraph()
    for item in data:
        source = item.get("source")
        target = item.get("target")
        relation = item.get("relation", "related_to")
        if source and target:
            G.add_edge(source, target, relation=relation)
    return G

def save_graph(graph, output_path):
    nx.write_gml(graph, output_path)

def convert_jsonl_to_graph(input_file, output_file):
    data = load_jsonl(input_file)
    graph = jsonl_to_graph(data)
    save_graph(graph, output_file)

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Convert JSONL relationships to GML graph.")
    parser.add_argument("input_file", help="Path to JSONL file with relationships")
    parser.add_argument("output_file", help="Path to save the output GML graph")
    args = parser.parse_args()

    convert_jsonl_to_graph(args.input_file, args.output_file)