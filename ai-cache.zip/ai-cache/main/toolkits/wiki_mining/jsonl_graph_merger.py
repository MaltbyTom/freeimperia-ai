# toolkits/wiki_mining/jsonl_graph_merger.py

import json
import os

def merge_jsonl_graphs(input_files, output_file):
    seen = set()
    with open(output_file, 'w', encoding='utf-8') as out_f:
        for file_path in input_files:
            with open(file_path, 'r', encoding='utf-8') as in_f:
                for line in in_f:
                    if line not in seen:
                        out_f.write(line)
                        seen.add(line)

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Merge multiple JSONL graph files into one deduplicated output.")
    parser.add_argument("inputs", nargs='+', help="List of input .jsonl files")
    parser.add_argument("-o", "--output", required=True, help="Output .jsonl file")
    args = parser.parse_args()
    merge_jsonl_graphs(args.inputs, args.output)