# toolkit/wiki_mining/wiki_parser.py

import os
import re
from typing import List, Tuple
from toolkit.wiki_mining.graph_data_model import Entity, Relationship, WikiGraph

WIKI_LINK_RE = re.compile(r"\[\[(.*?)\]\]")

def extract_links(text: str) -> List[str]:
    return WIKI_LINK_RE.findall(text)

def parse_wiki_page(title: str, content: str) -> Tuple[List[Entity], List[Relationship]]:
    entities = [Entity(name=title, wiki_link=f"[[{title}]]")]
    relationships = []

    links = extract_links(content)
    for link in links:
        relationships.append(
            Relationship(
                source=f"[[{title}]]",
                target=f"[[{link}]]",
                label="links to",
                sentence=None
            )
        )
    return entities, relationships

def build_graph_from_wiki(wiki_folder: str) -> WikiGraph:
    all_entities = []
    all_relationships = []
    seen = set()

    for filename in os.listdir(wiki_folder):
        if filename.endswith(".txt"):
            title = filename[:-4]
            with open(os.path.join(wiki_folder, filename), encoding="utf-8") as f:
                content = f.read()
            entities, relationships = parse_wiki_page(title, content)

            for e in entities:
                if e.name not in seen:
                    all_entities.append(e)
                    seen.add(e.name)

            all_relationships.extend(relationships)

    return WikiGraph(entities=all_entities, relationships=all_relationships)
