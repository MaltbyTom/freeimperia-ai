# File: toolkits/wiki_mining/graph_concepts_extractor.py

import re
import json
from collections import defaultdict

def extract_concepts_from_jsonl(input_path, output_path):
    concept_links = []
    concept_map = defaultdict(set)

    with open(input_path, 'r', encoding='utf-8') as infile:
        for line in infile:
            data = json.loads(line)
            source = data.get('source')
            target = data.get('target')
            relationship = data.get('relationship')
            context = data.get('context', "")

            if source and target and relationship:
                for token in re.findall(r'\[\[(.*?)\]\]', context):
                    if token != source and token != target:
                        concept_links.append({
                            'source': source,
                            'target': token,
                            'relationship': f'context: {relationship}',
                            'origin': 'concept_extractor'
                        })
                        concept_map[source].add(token)
                        concept_map[target].add(token)

    with open(output_path, 'w', encoding='utf-8') as outfile:
        for link in concept_links:
            outfile.write(json.dumps(link, ensure_ascii=False) + '\n')

    print(f"Extracted {len(concept_links)} concept links.")