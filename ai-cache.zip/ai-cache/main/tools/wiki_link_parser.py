# tools/wiki_link_parser.py

import re

WIKI_LINK_PATTERN = re.compile(r"\[\[([^\]|]+)(?:\|[^\]]+)?\]\]")

def extract_links(wiki_text):
    return list(set(WIKI_LINK_PATTERN.findall(wiki_text)))

def extract_links_from_pages(page_dict):
    result = {}
    for page_id, content in page_dict.items():
        result[page_id] = extract_links(content)
    return result