# tools/wiki_miner_main.py

"""
Tool: wiki_miner_main.py
Purpose: Fetch wiki pages via sitemap, extract [[links]], and emit JSONL relationship data
"""

import os
from tools.wiki_page_fetcher import fetch_wiki_pages_from_sitemap
from tools.wiki_link_parser import extract_links_from_wiki
import json

def mine_wiki_relationships(sitemap_url: str, output_file: str = "relationships.jsonl"):
    print(f"🔍 Mining wiki from sitemap: {sitemap_url}")
    page_map = fetch_wiki_pages_from_sitemap(sitemap_url)
    
    with open(output_file, "w", encoding="utf-8") as out_f:
        for page_id, content in page_map.items():
            links = extract_links_from_wiki(content)
            for link in links:
                json_line = {
                    "source": f"[[{page_id}]]",
                    "target": f"[[{link}]]",
                    "relationship": "links_to"
                }
                out_f.write(json.dumps(json_line, ensure_ascii=False) + "\n")

    print(f"✅ Relationship mining complete. Output saved to {output_file}")

if __name__ == "__main__":
    sitemap = "https://freeimperia.com/fiwiki/doku.php?id=start&do=index"
    mine_wiki_relationships(sitemap)
