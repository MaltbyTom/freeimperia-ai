# tools/wiki_page_fetcher.py

import requests
from urllib.parse import urljoin
import time

BASE_URL = "https://freeimperia.com/fiwiki/doku.php?id="

def fetch_page(page_id):
    url = urljoin(BASE_URL, page_id)
    response = requests.get(url)
    response.raise_for_status()
    return response.text

def fetch_all(pages, delay=1.0):
    result = {}
    for page in pages:
        try:
            print(f"Fetching: {page}")
            result[page] = fetch_page(page)
            time.sleep(delay)
        except Exception as e:
            print(f"Error fetching {page}: {e}")
    return result
