# dev_salvage_boot.md

## Overview

This file tracks the boot analysis and salvage integrity of the `dev_salvage` branch. The primary objective is to validate inherited behavioral stability from `main`, identify any session-based drifts, and document any proposed patches or behavioral corrections not encoded in stable files.

## Confirmed State

- Branch: `dev_salvage`
- Source branch: `main`
- Git diff: zero-result (no code divergence at time of forking)
- Loaded files:
  - config/core_rules.yaml
  - config/behavior_rules.yaml
  - config/system_behavior.yaml
  - config/memory_anchors.yaml
- Confirmed salvaged scripts (13 total)
  - ✅ scripts/wiki_relationship_extractor_utf8.py
  - ✅ scripts/jsonl_to_graph.py
  - ✅ scripts/graph_utils.py
  - ✅ scripts/jsonl_to_gml.py
  - ✅ scripts/jsonl_graph_merger.py
  - ✅ scripts/graph_filter.py
  - ✅ scripts/graph_concepts_extractor.py
  - ✅ config/core_rules.yaml (modified)
  - ✅ config/behavior_rules.md (new)
  - ✅ config/behavior_rules.yaml (new)
  - ✅ config/system_behavior.md (new)
  - ✅ config/system_behavior.yaml
  - ✅ config/memory_anchors.yaml

## Anomaly: `MEMORY STATUS` Behavior Drift

**Symptoms:**  
In the current boot session, the `[MEMORY STATUS: x/100]` header was initially interpreted as “boot memory load completeness” rather than “context token saturation.”

**Expected Behavior:**  
As established in prior sessions (now lost due to memory clearance), `[MEMORY STATUS]` should reflect active memory usage relative to context limits. It serves as an early warning system for potential overflow beyond `24,000` tokens.

**Cause:**  
No explicit rule for this interpretation was present in any of the four core files:
- `session_start.md`
- `core_rules.yaml`
- `behavior_rules.yaml`
- `system_behavior.yaml`

The current interpretation defaulted to “boot completion” due to lack of explicit guidance.

**Impact:**  
- May mislead during long sessions with memory pressure.
- Masks early warning behavior and introduces diagnostic ambiguity.

## Proposed Fixes

### Fix A: Amend `session_start.md`

Append the following section near the response format header block:

```md
## Memory Status Interpretation
The MEMORY STATUS (XX/100) header reflects approximate token saturation.
- 0/100 = empty context
- 100/100 = near memory limit (~24k tokens)
This is used to detect memory overflow risk, not load completion.