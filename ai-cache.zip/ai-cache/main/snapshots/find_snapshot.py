def find_snapshot(filter_string: str):
    search(f"site:freeimperia.com/ai-cache/main/snapshots/ fib_snapshot_{filter_string}")
    # Works with date filters like "20250417", partials like "b_", etc.
    # Outputs clickable filenames and preview of match strength