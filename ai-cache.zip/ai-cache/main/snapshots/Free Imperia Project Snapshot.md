# Free Imperia Project Snapshot
# This snapshot is designed to help restore project context and history, referencing key lore,
# tools, factions, and the site's structure for future reference and continuity.

project_info:
  project_name: "Free Imperia"
  core_world: "Arda"  # Middle-Earth after the events of Tolkien's stories.
  time_period: "10,500 years after the end of the War of the Ring (Dagor Dagorath is approaching)"
  campaign_theme: "The return of magic, the resurrection of the Elves, and the convergence of gods, demons, and powers from across the multiverse."
  primary_crisis: "The approaching end of the world (Dagor Dagorath), with multiple apocalyptic factions vying for control."
  key_factions:
    - "Elven Imperial Navy" (currently a hostile faction)
    - "Black Numenoreans" (hostile, remnants of the ancient Numenorean empire)
    - "Harnic Elves" (escaped from a technological apocalypse on Harn)
    - "Krynnic Elves" (escaped from a magical apocalypse on Krynn)
    - "Wa" (nominally friendly but a major political power)
    - "The Elven Imperial Navy" (a major military force, hostile but currently unaware of the Free Imperia's location)
    - "Ice Giants" (defeated, but possibly still a threat)
  major_worlds_and_locations:
    - "Arda" (Middle-earth, the core world)
    - "Krynn" (home of the Dragonlance setting, destroyed by the good dragons losing the Dragon Wars)
    - "Harn" (destroyed by a technological apocalypse)
    - "Free Imperia Sphere" (a backwater sphere discovered by refugees, now revealed to be part of Arda)
  key_timeline_events:
    - "Elves return to Arda, bringing magic back to the world."
    - "The war between gods and powers begins to unfold, with key divine entities attempting to break into the world."
    - "The growing threat of the Black Numenoreans, led by Ar-Pharazon, who are trying to return to Arda."
    - "The resurgence of old enemies, including Morgoth, Sauron, and Ungoliant (Lolth), who seek to conquer Arda once again."
    - "The resurrection of old enemies, including Tasha (Iggwilv), Orcus, and Asmodeus, who are personally involved in the Free Imperia's fate."

site_structure:
  primary_pages:
    - "Main Sitemap" (https://freeimperia.com/fiwiki/doku.php?id=start&do=index)
    - "Entities" (https://freeimperia.com/fiwiki/doku.php?id=entities)
    - "Places on Arda" (https://freeimperia.com/fiwiki/doku.php?id=places_on_arda)
    - "Locations" (https://freeimperia.com/fiwiki/doku.php?id=locations)
    - "Campaign History" (https://freeimperia.com/fiwiki/doku.php?id=campaign)
    - "History of Arda" (https://freeimperia.com/fiwiki/doku.php?id=history_of_arda)
    - "Kelestia" (https://freeimperia.com/fiwiki/doku.php?id=kelestia)
    - "Divine Powers" (URL unknown)
  tools:
    - "Microbrowser" for viewing relationship graphs
    - "Wiki Relationship Extractor" for extracting relationships from the wiki
    - "JSON to Graph" (https://freeimperia.com/ai-cache/main/scripts/jsonl_to_graph.py)
    - "JSON to GML" (https://freeimperia.com/ai-cache/main/scripts/jsonl_to_gml.py)
    - "Graph Concepts Extractor" for gathering and analyzing entities
    - "Graph Filter" for filtering relationships
  graphs and visualizations:
    - "Divine Power Graph" (https://freeimperia.com/fiwiki/graphs/divine/)
    - "Faction & Enemy Map" (https://freeimperia.com/fiwiki/graphs/faction_enemy_map/)
    - "Faction-Enemy Network" (https://freeimperia.com/fiwiki/graphs/faction_enemy_map.jsonl)

graph_tool_project:
  name: "Free Imperia Knowledge Grapher"
  purpose: >
    Create an interactive, multi-source graph viewer and editor that syncs with the Free Imperia wiki.
    The tool will analyze entities and relationships from the campaign, divine lore, faction interactions,
    and automatically extract these from DokuWiki source files.

  key_features:
    - DocuWiki-aware entity extraction:
        • Use links like [[Mica of the Nine]] as canonical references
        • Resolve internal redirects or aliases
    - Auto-generated knowledge graphs:
        • Factions & enemies
        • Divine powers & avatars
        • People & notable figures (up next)
        • Locations & planes
    - Visual microbrowser (hosted on fiwiki):
        • Clickable, styled graphs with linkouts to wiki pages
        • Filters for relationship type, strength, or theme
        • Suggestions for missing links or connections
    - Entity intelligence:
        • Tooltip rollovers show name, description, link
        • Multi-affiliation tracking (e.g., Thuringwethil = vampire, Sauronite, Morgothian, etc.)
    - Expandable JSONL pipeline:
        • Can be processed through `jsonl_to_graph.py`, `jsonl_graph_merger.py`, etc.
        • Easily rebuildable from snapshots or data exports

  upcoming_graphs:
    - people_and_figures_graph.jsonl
    - location_plane_portal_graph.jsonl
    - timeline_event_graph.jsonl

  file_pipeline:
    - Input: `.txt` or `.dokuwiki` source (wiki exports or scraper output)
    - Stage 1: `wiki_relationship_extractor_utf8.py`
    - Stage 2: `jsonl_to_graph.py`
    - Optional Merge: `jsonl_graph_merger.py`
    - Visualization: `jsonl_to_gml.py` → `.gml` for Gephi or hosted microbrowser
    - Hosting: `/fiwiki/graphs/` directory, linked from main site or microbrowser

  hosting_requirements:
    - Must live on `https://freeimperia.com/fiwiki/graphs/`
    - Interactive JS frontend (optional upgrade) could use D3.js or Vis.js for local browsing
    - Permission-sensitive: future consideration for player vs GM access levels

  roadmap:
    - ✅ Divine graph (complete)
    - ✅ Faction-enemy map (complete)
    - 🔜 People & Notable Figures graph (next target)
    - ⏳ Timeline Events & Prophecies graph
    - ⏳ Plane Convergence & Spelljammer Network graph

  developer_notes:
    - Project will benefit from caching identifiers and known aliases (e.g., Jesus = Aslan = Yashua = Son of the Emperor Over the Water)
    - Consider a plugin to write links back into the wiki if editor access is permitted
    - Graph suggestions could seed campaign plot points or AI-driven story development
    
notable_entities_and_concepts:
  - "Aslan" (son of the Emperor over the Water, aspect of Jesus)
  - "Jesus" (son of Yashua, aspect of Aslan)
  - "Eru" (Emperor over the Water, aspect of Yashua)
  - "Yashua" (father of Jesus, aspect of Eru)
  - "Morgoth" (ancient enemy, seeking to return to Arda)
  - "Sauron" (former servant of Morgoth, actively seeking to conquer Arda)
  - "Ungoliant" (possibly the same being as Lolth, a major threat)
  - "The Black Numenoreans" (ancient enemies of the elves, seeking to return to Arda)
  - "Ar-Pharazon" (King of Numenor, attempted to invade Valinor, seeking a return to power)
  - "Ice Giants" (hostile faction, possibly all destroyed but still a lingering threat)
  - "Lord Soth" (escaped from Krynn, an undead lich lord, now in Arda)
  - "Thuringwethil" (a powerful vampire lord, one of at least three in the world)
  - "Nazgul" (ringwraiths, still active in the world, possibly linked to the Free Imperia)
  - "Tasha" (Iggwilv, a major villain from D&D lore, a key enemy of the Free Imperia)
  - "Chemosh" (god of death, seeking revenge on Mica for the destruction of his avatar)
  - "Tiamat" (dragon goddess, also seeking revenge on Mica)

factions_and_powers:
  - "Elven Imperial Navy" (currently hostile, major military power)
  - "Wa" (nominally friendly, major foreign power)
  - "The Elven Imperial Navy" (possible future enemy, large military force)
  - "Ice Giants" (potentially all destroyed but still a looming threat)
  - "Lord Tokugawa" (ex-Shogun, leader of the Free Imperia's military)
  - "Mica" (hero, destroyer of Chemosh's avatar, currently a target of divine retribution)

tools_in_use:
  - "Wiki Relationship Extractor" (extracts relationships between entities, used to mine the wiki for key relationships)
  - "JSONL to Graph" (converts wiki data to graph format for visual analysis)
  - "Graph Concepts Extractor" (extracts conceptual relationships from wiki)
  - "JSON to GML" (converts extracted data to GML for graph visualization)
  - "Graph Filter" (used to filter and analyze graph data, identifying key relationships and patterns)
  - "Microbrowser" (visualizes and explores relationship graphs)

important_files:
  - "fib_snapshot_20250418_2214.yaml" (memory snapshot of current state)
  - "faction_enemy_map.jsonl" (contains the faction-enemy relationships)
  - "faction_enemy_map.gml" (graph format for visualization)
  - "divine_graph.jsonl" (contains the divine power relationships)
  - "graph_tools.py" (utility for processing and analyzing graph data)
  - "jsonl_to_graph.py" (script for generating graphs from JSONL data)

current_project_tasks:
  - Build and visualize relationship graphs for factions, divine powers, and enemies
  - Map key entities (such as gods, lords, factions, and political entities) into visual relationships
  - Continue refining the data extraction and relationship identification tools
  - Integrate dynamic links between wiki pages and the generated graphs for easier navigation and exploration
  - Add new entities and factions as they are introduced in the ongoing campaign narrative
  - Prepare for major enemy factions to become more active in the campaign

memory_management:
  - Snapshot system has been implemented to preserve key project data across sessions
  - Snapshot files are named in the format `fib_snapshot_YYYYMMDD_HHMM.yaml` for easy tracking
  - Project data is structured to minimize memory usage, but complex data may push system limits
  - Tools and scripts are kept up-to-date to reflect changes in project needs and goals
  - Major snapshot dumps (like this one) are crucial for regaining context during project transitions

lore:
  - Arda: "Core world for the setting. Middle-Earth, 10,500 years after Tolkien's timeline. Elves and dwarves originally came from Arda, and the world is central to the campaign's divine and magical struggles."
  - Free Imperia: "A multiversal refuge empire formed by survivors of apocalypses from worlds like Harn and Krynn. They discovered Arda after its magical suppression, leading to a reawakening of magic and the countdown to Dagor Dagorath."
  - Dagor Dagorath: "The apocalyptic final battle foreseen in Elven prophecy. It is the convergence point for all divine, demonic, and planar powers, aiming for a decisive conflict in Arda."
  - Spheres and Planar Travel: "Spelljammer and Planescape influences, with a focus on the Crystal Spheres. Arda is rediscovered after long ages of isolation."
  - Apocalypses:
      - Harn: "Destroyed by a technological apocalypse, with surviving elves seeking refuge elsewhere."
      - Krynn: "Suffered a magical collapse where the forces of good dragons lost the Dragon Wars."
      - Free Imperia’s Origins: "The empire is built by refugees from these worlds, who accidentally break into Arda's backwater sphere, sparking a resurgence of magic."

history_of_arda:
  - "The history of Arda includes the rise and fall of civilizations, notably the Elves, Dwarves, and Men. The return of magic has brought chaos and conflict."
  - "Key events: The rise of Morgoth, Sauron, and the fall of Númenor. The reemergence of powerful figures and factions from Arda’s past."
  - "The present timeline: 10,500 years after the end of Tolkien's story, with Dagor Dagorath approaching and many powers converging on Arda."
  - "The resurgence of the Elves and the connection to the Free Imperia: Elves returned after the accidental discovery of Arda, restoring magic and setting off the countdown."

divine_entities:
  - Aslan: "A divine figure tied to the 'Lion' archetype. Linked with Jesus and the Emperor over the Water."
  - Yashua: "A divine force linked with Jesus, embodying both divine justice and mercy."
  - Eru: "Also called the Emperor over the Water, representing the supreme divine power."
  - Jesus: "The son of Yashua, connected to the themes of sacrifice and salvation."
  - Chemosh: "A dark god, despised by the Free Imperia after Mica destroyed his avatar on Krynn."
  - Tiamat: "A powerful dragon goddess, particularly angry with the Free Imperia due to their interference with her schemes."
  - Sauron: "Morgoth’s lieutenant, seeking to return and conquer Arda once more."
  - Morgoth: "The original dark power of Arda, planning to break back in and claim dominion over the world."
  - Ungoliant: "A powerful and ancient spider-being, possibly linked to Lolth, and a key antagonist in Arda's future conflict."
  - Ar-Pharazon: "The last king of Númenor, whose failed invasion of Valinor still has ramifications."
  - Asmodeus: "A powerful devil, whose influence is felt across the planes. Acts as a major antagonist for the Free Imperia."

factions:
  - Free_Imperia: 
      description: "The empire built by refugees from apocalyptic worlds, now established in Arda."
      key_figures:
        - Mica: "A powerful figure who destroyed Chemosh’s avatar and triggered wrath from various dark powers."
        - Lord Tokugawa: "Exiled Shogun, now a general in the Free Imperia’s military."
  - Elven_Imperial_Navy:
      description: "An advanced elven faction that has become a major political and military power. They are hostile to the Free Imperia, although they have not yet discovered its location."
  - Black_Numenoreans:
      description: "A faction of Númenórean descent, harboring remnants of ancient power and desiring to return to their former glory."
      key_figures:
        - Ar-Pharazon: "The fallen king who still seeks revenge and retribution."
  - Wa: 
      description: "A nominally friendly power in the region, but its political landscape is complex, and it remains a major power."
  - Ice_Giants: 
      description: "A once-feared race that may have been wiped out, but if not, remains a significant threat."
      current_status: "Possibly all dead, but their threat remains significant if they survive."

enemies:
  - Morgoth:
      description: "The dark god of Arda who is planning his return, determined to take back control of the world."
  - Sauron:
      description: "Morgoth’s lieutenant, who seeks to dominate Arda with his dark influence and the power of the One Ring."
  - Ungoliant: 
      description: "A dark, ancient spider-being linked to Lolth. She is a significant threat to Arda and has a vast influence across the planes."
  - Tasha/Iggwilv:
      description: "A powerful archmage and demoness, with deep knowledge of dark magic. She holds a grudge against the Free Imperia after past conflicts."
  - Asmodeus:
      description: "An archdevil whose vengeance against the Free Imperia is well-known, particularly after their interference with his schemes."
  - Orcus:
      description: "A powerful demon lord of the undead, who seeks to spread death and corruption throughout Arda."
  - Thuringwethil:
      description: "A vampiric lieutenant, tied to dark powers and working against the Free Imperia."
  - Nazgul: 
      description: "Once human kings, now corrupted into undead servants of Sauron. They have found their way into the Free Imperia's timeline."
  - Lord Soth:
      description: "A death knight from Krynn who has escaped his fate, and now wanders the realms of the Free Imperia, seeking power and vengeance."

locations:
  - Arda:
      description: "The core world of the campaign, home to many factions, deities, and ancient secrets."
      places_of_interest:
        - Gondolin: "An ancient hidden city, now in ruins. It may have secret knowledge that will be important to the Free Imperia."
        - Valinor: "The blessed realm of the Valar, which remains a central mystery in the world’s lore. It was once the goal of the Elves, now a contested domain."
  - Harn:
      description: "A world destroyed by a technological apocalypse, home to a major branch of Elven refugees who fled before the world’s destruction."
  - Krynn:
      description: "A world now in ruin, where the good dragons lost the Dragon Wars. Many figures from this world play major roles in the Free Imperia’s struggles."
  - Moon_of_Arda:
      description: "The moon of Arda, inhabited by chaotic, neutral spider-folk who trade a rare metal, Nak, with the Free Imperia."
      population: "Spider-folk offspring of Ungoliant, known for their chaotic and secretive nature."
      trade_goods:
        - Nak: "A super metal with unique properties that is highly valued by the Free Imperia."

wildcards:
  - Elven_Imperial_Navy:
      description: "A large, powerful faction that does not yet know the location of the Free Imperia, but they are hostile and may discover them soon."
  - Free_Imperia_Military:
      description: "The Free Imperia’s own military, led by Lord Tokugawa, an exiled Shogun from Wa."
  - Elven_Factions: 
      description: "Multiple factions of elves, including those loyal to the Elven Imperial Navy, with some believing that the return of the elves is a critical part of Arda’s future."
  - Internal_Factions:
      description: "Various internal factions, including noble houses, churches, and organizations that form the backbone of the Free Imperia’s internal politics."
  - Holy_Roman_Empire_Analogy:
      description: "Like the Holy Roman Empire, the Free Imperia is a loose coalition of political entities that share a common goal but are often at odds with each other."

site_structure:
  - main_wiki: 
      description: "Central hub for the Free Imperia world, connecting lore, factions, and entities. Key information is housed here, and the wiki serves as the foundation for game-related content."
      key_index_pages:
        - campaign: "A summary of the campaign’s history, setting, and current events. This page gives a good overview of the ongoing narrative."
        - history_of_arda: "A detailed history of Arda, its civilizations, and major events. Crucial for understanding the divine and apocalyptic context."
        - factions: "Lists major factions, their goals, and power structures. This page links various factions to individuals, deities, and locations."
        - divine: "A page dedicated to the deities of the setting. It organizes the different divine powers, including their alignments, relationships, and domains."
        - places: "Detailed locations within Arda and beyond. This page houses maps, descriptions of realms, and important points of interest."
        - entities: "A page listing the significant beings—gods, demons, and powerful mortals—that shape the world."
        - locations_on_arda: "Detailed geographical regions and cities on Arda. Includes ancient ruins, powerful kingdoms, and secret places."

  - microbrowser:
      description: "A custom tool for navigating and interacting with the Free Imperia wiki. The microbrowser allows for visual interpretation of complex relationships between entities, factions, and lore."
      purpose: "Aims to help players quickly locate key content and visualize interactions without manually searching through long pages."
      features:
        - Relationship View: "Displays entities, factions, and their connections to one another, highlighting important allies, enemies, and neutral factions."
        - Interactivity: "Players can interact with the browser to explore specific factions, gods, and historical figures in detail, linking them to other relevant pages."
        - Mapping: "Shows the interwoven nature of the setting’s factions, divine entities, and the overarching campaign plot."
        - Dynamic Updates: "The browser updates automatically as new content and relationships are added to the wiki, providing real-time data."

microbrowser_interaction:
  - Purpose: "Navigates relationships between factions, deities, locations, and characters within the Free Imperia wiki."
  - Features:
      - Interactive Graphs: "The microbrowser presents a visual graph where entities are nodes, and their relationships are edges. Clicking a node or edge takes you to detailed wiki pages."
      - Visual Tools:
          - Timeline Integration: "Provides a visual timeline for historical events to track key moments in Arda’s history and the Free Imperia’s development."
          - Conflict Overlay: "Highlights areas of tension, war, and political strife, helping users see which factions or entities are currently in conflict."
          - Faction Grouping: "Groups factions based on their alliances, enemies, or shared goals, making it easier to see which factions have similar or opposing interests."
      - Custom Filters:
          - Conflict/Hostile/Neutral Filters: "Allows users to filter factions and characters by their relationships—whether they’re enemies, neutral, or allies."
          - Divine Filters: "Separates gods and divine powers into categories based on their domains (e.g., War, Magic, Chaos, Order)."
          - Location & Region Filters: "Displays factions and characters tied to specific locations within Arda and its adjacent spheres."

  - Output Format:
      - Visual Graphs: "Outputs dynamic graphs that are connected to relevant wiki pages for immediate review."
      - Data Export: "Users can export data from the microbrowser in .jsonl format for further analysis or integration with external tools."

observations:
  - Searchability:
      description: "The Free Imperia wiki is heavily indexed and linked, making it easy to search for key figures, factions, or lore. Each page has detailed metadata and cross-links to related content."
      - Strength: "Cross-linking between factions, divine entities, and historical events is incredibly useful for rapid exploration of complex connections."
      - Weakness: "The microbrowser does not yet support a full-text search feature, limiting deep query access for users who want to dig into specific content."
  - Usability:
      description: "The site is designed for ease of use, with intuitive navigation and a system of pages that flow logically into one another."
      - Strength: "A clean, minimalist design that prioritizes content accessibility over heavy aesthetic features. The layout is user-friendly, especially for new players."
      - Weakness: "Complex relationships might feel overwhelming at first, especially without a guide. The microbrowser helps with this but needs refinement."
  - Ongoing Development:
      description: "The wiki and the microbrowser are still evolving, with potential for more in-depth visual representations of divine and faction conflicts, as well as real-time updates from campaign progress."
      - Potential: "Future updates to the microbrowser could introduce multi-dimensional filters and more interactive elements to track campaign-specific developments."
