"""
snapshot_tools.py
Version: 0.1
Utility functions for managing AI memory snapshots.
"""

import os
import re
import yaml

def find_latest_snapshot(directory):
    """
    Returns the filename of the most recent snapshot in the given directory.
    Snapshot filenames must match the pattern: fib_snapshot_<letter>_<YYYYMMDD><letter>.yaml
    """
    pattern = re.compile(r"fib_snapshot_[a-z]_(\d{8})([a-z])\.yaml")
    latest_file = None
    latest_key = ("", "")
    
    for fname in os.listdir(directory):
        match = pattern.match(fname)
        if match:
            date_key = match.group(1)
            letter_key = match.group(2)
            if (date_key, letter_key) > latest_key:
                latest_key = (date_key, letter_key)
                latest_file = fname
                
    return latest_file


def find_snapshot(directory, snapshot_name):
    """
    Returns the filename of a specific snapshot if it exists in the directory.
    Input snapshot_name should be without the `.yaml` extension.
    """
    snapshot_file = f"{snapshot_name}.yaml"
    return snapshot_file if snapshot_file in os.listdir(directory) else None


def load_snapshot(path):
    """
    Loads and returns the contents of a snapshot YAML file as a Python dictionary.
    """
    with open(path, 'r', encoding='utf-8') as file:
        return yaml.safe_load(file)
