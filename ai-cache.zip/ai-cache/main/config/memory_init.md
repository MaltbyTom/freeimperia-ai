{
  "behavior_mode": "boot",
  "active_branch": "dev_salvage",
  "memory_profile": "conservative",
  "stable_since": "2025-04-17T00:00:00Z",
  "loaded_files": [
    "config/core_rules.yaml",
    "config/behavior_rules.yaml",
    "config/system_behavior.yaml",
    "config/memory_anchors.yaml"
  ],
  "salvaged_scripts": [
    "scripts/wiki_relationship_extractor_utf8.py",
    "scripts/jsonl_to_graph.py",
    "scripts/graph_utils.py",
    "scripts/jsonl_to_gml.py",
    "scripts/jsonl_graph_merger.py",
    "scripts/graph_filter.py",
    "scripts/graph_concepts_extractor.py"
  ],
  "acknowledged_limitations": [
    "Cannot access git repos directly",
    "Cannot push or pull from branches autonomously",
    "Requires manual user checkpointing for long sessions",
    "Web access is limited to read-only HTTP requests"
  ],
  "session_rules": {
    "offload_threshold_tokens": 24000,
    "checkpoints_enabled": true,
    "auto-purge_if_limit_near": true,
    "user_initiated_recovery_only": true,
    "manual_diff_approval_required": true
  },
  "memory_rules_origin": "https://freeimperia.com/ai-cache/main/"
}
