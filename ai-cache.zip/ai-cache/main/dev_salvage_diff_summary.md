# Dev Salvage Diff Summary
_Last generated: 2025-04-17_

## Overview
This document summarizes the key differences between the `dev` and `main` branches, focused around the 13 files confirmed as salvageable from the unstable session. This diff does not include behavioral divergence from chat interactions or AI memory but reflects file-level divergence.

---

## ✅ 13 Files Added or Modified in `dev_salvage`

### `config/` (6 files)

- `config/core_rules.yaml` — ✅ **Modified**
  - Behavior rules expanded to reflect better memory conservation and staging strategy.
  - Includes checkpoint-based pacing and offload triggers.

- `config/behavior_rules.md` — ✅ **New**
  - Markdown-formatted commentary and prose elaboration of AI behavioral limits and memory best practices.

- `config/behavior_rules.yaml` — ✅ **New**
  - Mirrors `behavior_rules.md` in structured YAML for parsing by scripts.

- `config/system_behavior.md` — ✅ **New**
  - Documentation of system-wide behavior including restart logic, purging, and caching.

- `config/memory_anchors.yaml` — ✅ **New**
  - Intended for storing persistent memory anchors (e.g. rule enforcers, context prioritizers).

- `config/system_behavior.yaml` — ✅ **New**
  - YAML implementation of the rules documented in `system_behavior.md`.

---

### `scripts/` (7 files)

- `scripts/wiki_relationship_extractor_utf8.py` — ✅ **New**
  - Extracts internal DocuWiki relationships using UTF-8 encoding.
  - Uses `[[Link Format]]` as canonical identifiers.

- `scripts/jsonl_to_graph.py` — ✅ **New**
  - Converts `.jsonl` format extracted entities into networkx-compatible graphs.
  - Preserves DocuWiki linkage in node identifiers.

- `scripts/graph_utils.py` — ✅ **New**
  - General utilities for graph construction, relationship mapping, and type validation.

- `scripts/jsonl_to_gml.py` — ✅ **New**
  - Exports graph data to `.gml` format for use in Gephi or similar tools.

- `scripts/jsonl_graph_merger.py` — ✅ **New**
  - Merges multiple JSONL graphs while resolving conflicts and duplicate nodes.

- `scripts/graph_filter.py` — ✅ **New**
  - Filters graphs by relationship type, entity tag, or filename prefix.

- `scripts/graph_concepts_extractor.py` — ✅ **New**
  - Experimental file to generate higher-level concepts from entity graphs.
  - May need review for compatibility/stability.

---

## 🟨 Minor Structural Differences

- File naming and folder structure are clean and valid across branches.
- No harmful mutations to existing core or system behavior in `main`.

---

## 🟥 High-Risk Behavior Divergence (Chat Memory Only)

- Some memory states in the failed dev session introduced looping and hallucination due to aggressive recursive boot logic.
- These are not stored in files, but **might return** if salvaged code is not run in a stable boot mode.

---

## ✅ Recommendation

- **Retain all 13 files in `dev_salvage`**
- Use the bootloader from `main` and incrementally reintroduce new memory behavior.
- Tag `graph_concepts_extractor.py` for early testing and crash resistance review.

